
package cofh.api.core;

public interface ISimpleRegistry {

    public boolean register(String playerName, String URL);

}
