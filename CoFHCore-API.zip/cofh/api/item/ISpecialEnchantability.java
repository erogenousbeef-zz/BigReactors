
package cofh.api.item;

import net.minecraft.item.ItemStack;

public interface ISpecialEnchantability {

    public int getItemEnchantability(ItemStack theStack);

}
