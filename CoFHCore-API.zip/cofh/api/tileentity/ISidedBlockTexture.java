
package cofh.api.tileentity;

import net.minecraft.util.Icon;

public interface ISidedBlockTexture {

    public Icon getBlockTexture(int side, int pass);

}
