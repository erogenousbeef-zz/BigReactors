package powercrystals.minefactoryreloaded.api;

import net.minecraft.entity.player.EntityPlayer;

public interface ILiquidDrinkHandler
{
	public void onDrink(EntityPlayer player);
}
