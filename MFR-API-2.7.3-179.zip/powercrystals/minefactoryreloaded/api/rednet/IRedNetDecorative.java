package powercrystals.minefactoryreloaded.api.rednet;

public interface IRedNetDecorative
{

}
