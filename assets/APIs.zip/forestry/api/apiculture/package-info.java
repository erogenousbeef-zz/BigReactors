@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|apiculture")
package forestry.api.apiculture;
import cpw.mods.fml.common.API;