package forestry.api.circuits;

public class ChipsetManager {

	public static ISolderManager solderManager;
	public static ICircuitRegistry circuitRegistry;

}
