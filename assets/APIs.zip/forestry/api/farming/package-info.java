@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|farming")
package forestry.api.farming;
import cpw.mods.fml.common.API;