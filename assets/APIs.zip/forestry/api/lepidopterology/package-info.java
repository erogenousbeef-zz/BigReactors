@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|lepidopterology")
package forestry.api.lepidopterology;
import cpw.mods.fml.common.API;