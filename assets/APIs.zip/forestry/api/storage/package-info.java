@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|storage")
package forestry.api.storage;
import cpw.mods.fml.common.API;